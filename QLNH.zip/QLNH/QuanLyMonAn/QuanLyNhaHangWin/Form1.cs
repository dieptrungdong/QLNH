﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyMonAn
{
    public partial class Form1 : Form
    {
        MonAnBLL bllMA;
        NguyenLieuBLL bllNL;
        public Form1()
        {
            InitializeComponent();
            bllMA = new MonAnBLL();
            bllNL = new NguyenLieuBLL();
        }
        public void ShowAllMonAn()
        {
            DataTable dt = bllMA.GetAllMonAn();
            dataGrindViewMonAn.DataSource = dt;
        }
        public void ShowAllNguyenLieu()
        {
            DataTable dt = bllNL.GetAllNguyenLieu();
            dataGridViewNguyenLieu.DataSource = dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowAllMonAn();
            ShowAllNguyenLieu();
        }
        public bool CheckDataMonAn()
        {
            if (string.IsNullOrEmpty(txtMaMonAn.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã Món Ăn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaMonAn.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtTen.Text))
            {
                MessageBox.Show("Bạn chưa nhập Tên Món.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTen.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtLoai.Text))
            {
                MessageBox.Show("Bạn chưa nhập Loại Món ăn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtLoai.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtGia.Text))
            {
                MessageBox.Show("Bạn chưa nhập Giá.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGia.Focus();
                return false;
            }
            return true;
        }
        public bool CheckDataNguyenLieu()
        {
            if (string.IsNullOrEmpty(txtMaNguyenLieu.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã Nguyên Liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaNguyenLieu.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtTenNguyenLieu.Text))
            {
                MessageBox.Show("Bạn chưa nhập Tên Nguyên Liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenNguyenLieu.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtSLNL.Text))
            {
                MessageBox.Show("Bạn chưa nhập Số lượng nguyên liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSLNL.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtDonVi.Text))
            {
                MessageBox.Show("Bạn chưa nhập Đơn vị cho nguyên liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDonVi.Focus();
                return false;
            }
            return true;
        }

        private void MaMonAn_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TenMonAn_TextChanged(object sender, EventArgs e)
        {

        }

        private void them_Click(object sender, EventArgs e)
        {
            if (CheckDataMonAn())
            {
                MonAn ma = new MonAn();
                ma.MaMonAn = txtMaMonAn.Text;
                ma.Ten = txtTen.Text;
                ma.Loai = txtLoai.Text;
                ma.Gia = txtGia.Text;

                if (bllMA.InsertMonAn(ma))
                    ShowAllMonAn();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void Gia_Click(object sender, EventArgs e)
        {

        }

        private void Loai_Click(object sender, EventArgs e)
        {

        }

        private void TenMonAn_Click(object sender, EventArgs e)
        {

        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            if (CheckDataMonAn())
            {
                MonAn ma = new MonAn();
                ma.MaMonAn = txtMaMonAn.Text;
                ma.Ten = txtTen.Text;
                ma.Loai = txtLoai.Text;
                ma.Gia = txtGia.Text;

                if (bllMA.UpdateMonAn(ma))
                    ShowAllMonAn();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xoá hay không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                MonAn ma = new MonAn();
                ma.MaMonAn = txtMaMonAn.Text;
                if (bllMA.DeleteMonAn(ma))
                    ShowAllMonAn();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        private void dataGrindViewMonAn_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index >= 0)
            {
                txtMaMonAn.Text = dataGrindViewMonAn.Rows[index].Cells["MaMonAn"].Value.ToString();
                txtTen.Text = dataGrindViewMonAn.Rows[index].Cells["Ten"].Value.ToString();
                txtLoai.Text = dataGrindViewMonAn.Rows[index].Cells["Loai"].Value.ToString();
                txtGia.Text = dataGrindViewMonAn.Rows[index].Cells["Gia"].Value.ToString();

                string MaMonAn = dataGrindViewMonAn.Rows[e.RowIndex].Cells["MaMonAn"].Value.ToString();
                DataTable dt = bllMA.GetCongThuc(MaMonAn);
                dataGrindCongThuc.DataSource = dt;
            }
        }

        private void txttimkiem_TextChanged(object sender, EventArgs e)
        {
            string value = txttimkiem.Text;
            if (!string.IsNullOrEmpty(value))
            {
                DataTable dt = bllMA.TimMonAn(value);
                dataGrindViewMonAn.DataSource = dt;
            }
            else
                ShowAllMonAn();
        }

        private void txtLoai_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGia_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {

        }

        private void dataGrindCongThuc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbCongThuc_Click(object sender, EventArgs e)
        {

        }

        private void btnThemNLvaoCT_Click(object sender, EventArgs e)
        {
        }

        private void btnThemNL_Click(object sender, EventArgs e)
        {
            if (CheckDataNguyenLieu())
            {
                NguyenLieu nl = new NguyenLieu();
                nl.MaNguyenLieu = txtMaNguyenLieu.Text;
                nl.TenNguyenLieu = txtTenNguyenLieu.Text;
                nl.SoLuong = txtSLNL.Text;
                nl.DonViTinh = txtDonVi.Text;

                if (bllNL.InsertNguyenLieu(nl))
                    ShowAllNguyenLieu();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnSuaNL_Click(object sender, EventArgs e)
        {
            if (CheckDataNguyenLieu())
            {
                NguyenLieu nl = new NguyenLieu();
                nl.MaNguyenLieu = txtMaNguyenLieu.Text;
                nl.TenNguyenLieu = txtTenNguyenLieu.Text;
                nl.SoLuong = txtSLNL.Text;
                nl.DonViTinh = txtDonVi.Text;

                if (bllNL.UpdateNguyenLieu(nl))
                    ShowAllNguyenLieu();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnXoaNL_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xoá hay không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                NguyenLieu nl = new NguyenLieu();
                nl.MaNguyenLieu = txtMaNguyenLieu.Text;
                nl.TenNguyenLieu = txtTenNguyenLieu.Text;
                nl.SoLuong = txtSLNL.Text;
                nl.DonViTinh = txtDonVi.Text;

                if (bllNL.DeleteNguyenLieu(nl))
                    ShowAllNguyenLieu();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void dataGridViewNguyenLieu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index >= 0)
            {
                txtMaNguyenLieu.Text = dataGridViewNguyenLieu.Rows[index].Cells["MaNguyenLieu"].Value.ToString();
                txtTenNguyenLieu.Text = dataGridViewNguyenLieu.Rows[index].Cells["TenNguyenLieu"].Value.ToString();
                txtSLNL.Text = dataGridViewNguyenLieu.Rows[index].Cells["SoLuong"].Value.ToString();
                txtDonVi.Text = dataGridViewNguyenLieu.Rows[index].Cells["DonViTinh"].Value.ToString();
            }
        }

        private void txtFindNL_TextChanged(object sender, EventArgs e)
        {
            string value = txtFindNL.Text;
            if (!string.IsNullOrEmpty(value))
            {
                DataTable dt = bllNL.TimNguyenLieu(value);
                dataGridViewNguyenLieu.DataSource = dt;
            }
            else
                ShowAllNguyenLieu();
        }
        private void lbdonvi_Click(object sender, EventArgs e)
        {

        }

        private void lbtennl_Click(object sender, EventArgs e)
        {

        }
    }
}