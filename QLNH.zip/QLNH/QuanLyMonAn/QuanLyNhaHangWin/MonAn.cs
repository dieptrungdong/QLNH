﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyMonAn
{
    class MonAn
    {
        public string MaMonAn { get; set; }
        public string Ten {  get; set; }
        public string Loai { get; set; }
        public string Gia { get; set; }
    }
    class NguyenLieu
    {
        public string MaNguyenLieu { get; set; }
   
        public string TenNguyenLieu { get; set; }
        public string SoLuong { get; set; }
        public string DonViTinh { get; set; }
    }
}
