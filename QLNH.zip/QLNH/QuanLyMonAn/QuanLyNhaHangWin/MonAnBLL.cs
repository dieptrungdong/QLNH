﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using QuanLyNhaHangWin;
namespace QuanLyMonAn
{
    class MonAnBLL
    {
        MonAnDAL dalMA;
        public MonAnBLL()
        {
            dalMA = new MonAnDAL();
        }
        public DataTable GetAllMonAn()
        {
            return dalMA.GetAllMonAn();
        }
        public bool InsertMonAn(MonAn ma)
        {
            return dalMA.InsertMonAn(ma);
        }
        public bool UpdateMonAn(MonAn ma)
        {
            return dalMA.UpdateMonAn(ma);
        }
        public bool DeleteMonAn(MonAn ma)
        {
            return dalMA.DeleteMonAn(ma);
        }
        public DataTable TimMonAn(string ma)
        {
            return dalMA.TimMonAn(ma);
        }
        public DataTable GetCongThuc(string MaMonAn)
        {
            return dalMA.GetCongThuc(MaMonAn);
        }
    }
    class NguyenLieuBLL
    {
        NguyenLieuDAL dalNL;
        public NguyenLieuBLL()
        {
            dalNL = new NguyenLieuDAL();
        }
        public DataTable GetAllNguyenLieu()
        {
            return dalNL.GetAllNguyenLieu();
        }
        public bool InsertNguyenLieu(NguyenLieu NL)
        {
            return dalNL.InsertNguyenLieu(NL);
        }
        public bool UpdateNguyenLieu(NguyenLieu NL)
        {
            return dalNL.UpdateNguyenLieu(NL);
        }
        public bool DeleteNguyenLieu(NguyenLieu NL)
        {
            return dalNL.DeleteNguyenLieu(NL);
        }
        public DataTable TimNguyenLieu(string NL)
        {
            return dalNL.TimNguyenLieu(NL);
        }
    }
}
