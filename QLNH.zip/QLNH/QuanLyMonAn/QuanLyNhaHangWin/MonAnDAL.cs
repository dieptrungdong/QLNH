﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyMonAn
{
    class MonAnDAL
    {
        dataConnection dc;
        SqlDataAdapter da;
        SqlCommand cmd;
        public MonAnDAL()
        {
            dc = new dataConnection();
        }
        public DataTable GetAllMonAn()
        {
            string sql = "SELECT * from MonAn";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public bool InsertMonAn(MonAn ma)
        {
            string sql = "INSERT INTO MonAn(MaMonAn, Ten, Loai, Gia) VALUES(@MaMonAn, @Ten, @Loai, @Gia)";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaMonAn", SqlDbType.Char).Value = ma.MaMonAn;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar).Value = ma.Ten;
                cmd.Parameters.Add("@Loai", SqlDbType.VarChar).Value = ma.Loai;
                cmd.Parameters.Add("@Gia", SqlDbType.Decimal).Value = ma.Gia;
                cmd.ExecuteNonQuery();
                con.Close() ;
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool UpdateMonAn(MonAn ma)
        {
            string sql = "UPDATE MonAn SET Ten=@Ten, Loai=@Loai, Gia=@Gia WHERE MaMonAn=@MaMonAn";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaMonAn", SqlDbType.Char).Value = ma.MaMonAn;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar).Value = ma.Ten;
                cmd.Parameters.Add("@Loai", SqlDbType.NVarChar).Value = ma.Loai;
                cmd.Parameters.Add("@Gia", SqlDbType.Decimal).Value = ma.Gia;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool DeleteMonAn(MonAn ma)
        {
            string sql = "DELETE MonAn WHERE MaMonAn=@MaMonAn";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaMonAn", SqlDbType.Char).Value = ma.MaMonAn;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public DataTable TimMonAn(string ma)
        {
            string sql = "SELECT * FROM MonAn Where Ten like N'%" + ma + "'";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public DataTable GetCongThuc(string MaMonAn)
        {
            string sql = "SELECT MonAn.MaMonAn, MonAn.Ten, NguyenLieu.TenNguyenLieu, MonAnNguyenLieu.SoLuong FROM MonAn JOIN MonAnNguyenLieu ON MonAn.MaMonAn = MonAnNguyenLieu.MaMonAn JOIN NguyenLieu ON MonAnNguyenLieu.MaNguyenLieu = NguyenLieu.MaNguyenLieu WHERE MonAn.MaMonAn = @MaMonAn";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            da.SelectCommand.Parameters.AddWithValue("@MaMonAn", MaMonAn);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
    }
    class NguyenLieuDAL
    {
        dataConnection dc;
        SqlDataAdapter da;
        SqlCommand cmd;
        public NguyenLieuDAL()
        {
            dc = new dataConnection();
        }
        public DataTable GetAllNguyenLieu()
        {
            string sql = "SELECT * from NguyenLieu";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public bool InsertNguyenLieu(NguyenLieu nl)
        {
            string sql = "INSERT INTO NguyenLieu(MaNguyenLieu, TenNguyenLieu, SoLuong, DonViTinh) VALUES(@MaNguyenLieu, @TenNguyenLieu, @SoLuong, @DonViTinh)";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNguyenLieu", SqlDbType.Char).Value = nl.MaNguyenLieu;
                cmd.Parameters.Add("@TenNguyenLieu", SqlDbType.NVarChar).Value = nl.TenNguyenLieu;
                cmd.Parameters.Add("@SoLuong", SqlDbType.Decimal).Value = nl.SoLuong;
                cmd.Parameters.Add("@DonViTinh", SqlDbType.NVarChar).Value = nl.DonViTinh;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool UpdateNguyenLieu(NguyenLieu nl)
        {
            string sql = "UPDATE NguyenLieu SET TenNguyenLieu=@TenNguyenLieu, SoLuong=@SoLuong, DonViTinh=@DonViTinh WHERE MaNguyenLieu=@MaNguyenLieu";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNguyenLieu", SqlDbType.Char).Value = nl.MaNguyenLieu;
                cmd.Parameters.Add("@TenNguyenLieu", SqlDbType.NVarChar).Value = nl.TenNguyenLieu;
                cmd.Parameters.Add("@SoLuong", SqlDbType.Decimal).Value = nl.SoLuong;
                cmd.Parameters.Add("@DonViTinh", SqlDbType.NVarChar).Value = nl.DonViTinh;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool DeleteNguyenLieu(NguyenLieu nl)
        {
            string sql = "DELETE NguyenLieu WHERE MaNguyenLieu=@MaNguyenLieu";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNguyenLieu", SqlDbType.Char).Value = nl.MaNguyenLieu;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public DataTable TimNguyenLieu(string nl)
        {
            string sql = "SELECT * FROM NguyenLieu Where TenNguyenLieu like N'%" + nl + "'";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
    }
}
