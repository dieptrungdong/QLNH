﻿namespace QuanLyMonAn
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrindViewMonAn = new System.Windows.Forms.DataGridView();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.txtMaMonAn = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtLoai = new System.Windows.Forms.TextBox();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.lbMaMonAn = new System.Windows.Forms.Label();
            this.lbTen = new System.Windows.Forms.Label();
            this.lbLoai = new System.Windows.Forms.Label();
            this.lbGia = new System.Windows.Forms.Label();
            this.btnthem = new System.Windows.Forms.Button();
            this.txttimkiem = new System.Windows.Forms.TextBox();
            this.btnTimkiem = new System.Windows.Forms.Label();
            this.dataGrindCongThuc = new System.Windows.Forms.DataGridView();
            this.lbCongThuc = new System.Windows.Forms.Label();
            this.timnl = new System.Windows.Forms.Label();
            this.txtFindNL = new System.Windows.Forms.TextBox();
            this.btnThemNL = new System.Windows.Forms.Button();
            this.lbdonvi = new System.Windows.Forms.Label();
            this.lbsoluongnl = new System.Windows.Forms.Label();
            this.lbtennl = new System.Windows.Forms.Label();
            this.lbmanl = new System.Windows.Forms.Label();
            this.txtDonVi = new System.Windows.Forms.TextBox();
            this.txtSLNL = new System.Windows.Forms.TextBox();
            this.txtTenNguyenLieu = new System.Windows.Forms.TextBox();
            this.txtMaNguyenLieu = new System.Windows.Forms.TextBox();
            this.btnXoaNL = new System.Windows.Forms.Button();
            this.btnSuaNL = new System.Windows.Forms.Button();
            this.dataGridViewNguyenLieu = new System.Windows.Forms.DataGridView();
            this.lbma = new System.Windows.Forms.Label();
            this.lbkho = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindViewMonAn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindCongThuc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNguyenLieu)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrindViewMonAn
            // 
            this.dataGrindViewMonAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrindViewMonAn.Location = new System.Drawing.Point(22, 333);
            this.dataGrindViewMonAn.Name = "dataGrindViewMonAn";
            this.dataGrindViewMonAn.RowHeadersWidth = 51;
            this.dataGrindViewMonAn.RowTemplate.Height = 24;
            this.dataGrindViewMonAn.Size = new System.Drawing.Size(349, 198);
            this.dataGrindViewMonAn.TabIndex = 0;
            this.dataGrindViewMonAn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrindViewMonAn_CellClick);
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(104, 262);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(75, 36);
            this.btnsua.TabIndex = 2;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = true;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(185, 262);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(75, 36);
            this.btnxoa.TabIndex = 4;
            this.btnxoa.Text = "Xoá";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // txtMaMonAn
            // 
            this.txtMaMonAn.Location = new System.Drawing.Point(195, 15);
            this.txtMaMonAn.Name = "txtMaMonAn";
            this.txtMaMonAn.Size = new System.Drawing.Size(187, 22);
            this.txtMaMonAn.TabIndex = 5;
            this.txtMaMonAn.TextChanged += new System.EventHandler(this.MaMonAn_TextChanged);
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(195, 68);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(187, 22);
            this.txtTen.TabIndex = 6;
            this.txtTen.TextChanged += new System.EventHandler(this.TenMonAn_TextChanged);
            // 
            // txtLoai
            // 
            this.txtLoai.Location = new System.Drawing.Point(195, 120);
            this.txtLoai.Name = "txtLoai";
            this.txtLoai.Size = new System.Drawing.Size(187, 22);
            this.txtLoai.TabIndex = 7;
            this.txtLoai.TextChanged += new System.EventHandler(this.txtLoai_TextChanged);
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(195, 178);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(187, 22);
            this.txtGia.TabIndex = 8;
            this.txtGia.TextChanged += new System.EventHandler(this.txtGia_TextChanged);
            // 
            // lbMaMonAn
            // 
            this.lbMaMonAn.AutoSize = true;
            this.lbMaMonAn.Location = new System.Drawing.Point(101, 18);
            this.lbMaMonAn.Name = "lbMaMonAn";
            this.lbMaMonAn.Size = new System.Drawing.Size(74, 16);
            this.lbMaMonAn.TabIndex = 9;
            this.lbMaMonAn.Text = "Mã Món Ăn";
            this.lbMaMonAn.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbTen
            // 
            this.lbTen.AutoSize = true;
            this.lbTen.Location = new System.Drawing.Point(101, 71);
            this.lbTen.Name = "lbTen";
            this.lbTen.Size = new System.Drawing.Size(79, 16);
            this.lbTen.TabIndex = 10;
            this.lbTen.Text = "Tên Món Ăn";
            this.lbTen.Click += new System.EventHandler(this.TenMonAn_Click);
            // 
            // lbLoai
            // 
            this.lbLoai.AutoSize = true;
            this.lbLoai.Location = new System.Drawing.Point(101, 123);
            this.lbLoai.Name = "lbLoai";
            this.lbLoai.Size = new System.Drawing.Size(33, 16);
            this.lbLoai.TabIndex = 11;
            this.lbLoai.Text = "Loại";
            this.lbLoai.Click += new System.EventHandler(this.Loai_Click);
            // 
            // lbGia
            // 
            this.lbGia.AutoSize = true;
            this.lbGia.Location = new System.Drawing.Point(101, 181);
            this.lbGia.Name = "lbGia";
            this.lbGia.Size = new System.Drawing.Size(28, 16);
            this.lbGia.TabIndex = 12;
            this.lbGia.Text = "Giá";
            this.lbGia.Click += new System.EventHandler(this.Gia_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(23, 262);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(75, 36);
            this.btnthem.TabIndex = 14;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.them_Click);
            // 
            // txttimkiem
            // 
            this.txttimkiem.Location = new System.Drawing.Point(195, 220);
            this.txttimkiem.Name = "txttimkiem";
            this.txttimkiem.Size = new System.Drawing.Size(187, 22);
            this.txttimkiem.TabIndex = 16;
            this.txttimkiem.TextChanged += new System.EventHandler(this.txttimkiem_TextChanged);
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.AutoSize = true;
            this.btnTimkiem.Location = new System.Drawing.Point(101, 226);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(79, 16);
            this.btnTimkiem.TabIndex = 17;
            this.btnTimkiem.Text = "Nhập đề tìm";
            this.btnTimkiem.Click += new System.EventHandler(this.btnTimkiem_Click);
            // 
            // dataGrindCongThuc
            // 
            this.dataGrindCongThuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrindCongThuc.Location = new System.Drawing.Point(377, 333);
            this.dataGrindCongThuc.Name = "dataGrindCongThuc";
            this.dataGrindCongThuc.RowHeadersWidth = 51;
            this.dataGrindCongThuc.RowTemplate.Height = 24;
            this.dataGrindCongThuc.Size = new System.Drawing.Size(451, 198);
            this.dataGrindCongThuc.TabIndex = 18;
            this.dataGrindCongThuc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrindCongThuc_CellContentClick);
            // 
            // lbCongThuc
            // 
            this.lbCongThuc.AutoSize = true;
            this.lbCongThuc.Location = new System.Drawing.Point(540, 314);
            this.lbCongThuc.Name = "lbCongThuc";
            this.lbCongThuc.Size = new System.Drawing.Size(120, 16);
            this.lbCongThuc.TabIndex = 19;
            this.lbCongThuc.Text = "Công Thức Món Ăn";
            this.lbCongThuc.Click += new System.EventHandler(this.lbCongThuc_Click);
            // 
            // timnl
            // 
            this.timnl.AutoSize = true;
            this.timnl.Location = new System.Drawing.Point(501, 226);
            this.timnl.Name = "timnl";
            this.timnl.Size = new System.Drawing.Size(79, 16);
            this.timnl.TabIndex = 32;
            this.timnl.Text = "Nhập đề tìm";
            // 
            // txtFindNL
            // 
            this.txtFindNL.Location = new System.Drawing.Point(622, 220);
            this.txtFindNL.Name = "txtFindNL";
            this.txtFindNL.Size = new System.Drawing.Size(187, 22);
            this.txtFindNL.TabIndex = 31;
            this.txtFindNL.TextChanged += new System.EventHandler(this.txtFindNL_TextChanged);
            // 
            // btnThemNL
            // 
            this.btnThemNL.Location = new System.Drawing.Point(834, 18);
            this.btnThemNL.Name = "btnThemNL";
            this.btnThemNL.Size = new System.Drawing.Size(131, 36);
            this.btnThemNL.TabIndex = 30;
            this.btnThemNL.Text = "Thêm Vào Kho";
            this.btnThemNL.UseVisualStyleBackColor = true;
            this.btnThemNL.Click += new System.EventHandler(this.btnThemNL_Click);
            // 
            // lbdonvi
            // 
            this.lbdonvi.AutoSize = true;
            this.lbdonvi.Location = new System.Drawing.Point(501, 184);
            this.lbdonvi.Name = "lbdonvi";
            this.lbdonvi.Size = new System.Drawing.Size(46, 16);
            this.lbdonvi.TabIndex = 29;
            this.lbdonvi.Text = "Đơn Vị";
            this.lbdonvi.Click += new System.EventHandler(this.lbdonvi_Click);
            // 
            // lbsoluongnl
            // 
            this.lbsoluongnl.AutoSize = true;
            this.lbsoluongnl.Location = new System.Drawing.Point(501, 136);
            this.lbsoluongnl.Name = "lbsoluongnl";
            this.lbsoluongnl.Size = new System.Drawing.Size(64, 16);
            this.lbsoluongnl.TabIndex = 28;
            this.lbsoluongnl.Text = "Số Lượng";
            // 
            // lbtennl
            // 
            this.lbtennl.AutoSize = true;
            this.lbtennl.Location = new System.Drawing.Point(501, 84);
            this.lbtennl.Name = "lbtennl";
            this.lbtennl.Size = new System.Drawing.Size(109, 16);
            this.lbtennl.TabIndex = 27;
            this.lbtennl.Text = "Tên Nguyên Liệu";
            this.lbtennl.Click += new System.EventHandler(this.lbtennl_Click);
            // 
            // lbmanl
            // 
            this.lbmanl.AutoSize = true;
            this.lbmanl.Location = new System.Drawing.Point(501, 31);
            this.lbmanl.Name = "lbmanl";
            this.lbmanl.Size = new System.Drawing.Size(104, 16);
            this.lbmanl.TabIndex = 26;
            this.lbmanl.Text = "Mã Nguyên Liệu";
            // 
            // txtDonVi
            // 
            this.txtDonVi.Location = new System.Drawing.Point(622, 178);
            this.txtDonVi.Name = "txtDonVi";
            this.txtDonVi.Size = new System.Drawing.Size(187, 22);
            this.txtDonVi.TabIndex = 25;
            // 
            // txtSLNL
            // 
            this.txtSLNL.Location = new System.Drawing.Point(622, 130);
            this.txtSLNL.Name = "txtSLNL";
            this.txtSLNL.Size = new System.Drawing.Size(187, 22);
            this.txtSLNL.TabIndex = 24;
            // 
            // txtTenNguyenLieu
            // 
            this.txtTenNguyenLieu.Location = new System.Drawing.Point(622, 78);
            this.txtTenNguyenLieu.Name = "txtTenNguyenLieu";
            this.txtTenNguyenLieu.Size = new System.Drawing.Size(187, 22);
            this.txtTenNguyenLieu.TabIndex = 23;
            // 
            // txtMaNguyenLieu
            // 
            this.txtMaNguyenLieu.Location = new System.Drawing.Point(622, 25);
            this.txtMaNguyenLieu.Name = "txtMaNguyenLieu";
            this.txtMaNguyenLieu.Size = new System.Drawing.Size(187, 22);
            this.txtMaNguyenLieu.TabIndex = 22;
            // 
            // btnXoaNL
            // 
            this.btnXoaNL.Location = new System.Drawing.Point(1052, 18);
            this.btnXoaNL.Name = "btnXoaNL";
            this.btnXoaNL.Size = new System.Drawing.Size(75, 36);
            this.btnXoaNL.TabIndex = 21;
            this.btnXoaNL.Text = "Xoá";
            this.btnXoaNL.UseVisualStyleBackColor = true;
            this.btnXoaNL.Click += new System.EventHandler(this.btnXoaNL_Click);
            // 
            // btnSuaNL
            // 
            this.btnSuaNL.Location = new System.Drawing.Point(971, 18);
            this.btnSuaNL.Name = "btnSuaNL";
            this.btnSuaNL.Size = new System.Drawing.Size(75, 36);
            this.btnSuaNL.TabIndex = 20;
            this.btnSuaNL.Text = "Sửa";
            this.btnSuaNL.UseVisualStyleBackColor = true;
            this.btnSuaNL.Click += new System.EventHandler(this.btnSuaNL_Click);
            // 
            // dataGridViewNguyenLieu
            // 
            this.dataGridViewNguyenLieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNguyenLieu.Location = new System.Drawing.Point(834, 77);
            this.dataGridViewNguyenLieu.Name = "dataGridViewNguyenLieu";
            this.dataGridViewNguyenLieu.RowHeadersWidth = 51;
            this.dataGridViewNguyenLieu.RowTemplate.Height = 24;
            this.dataGridViewNguyenLieu.Size = new System.Drawing.Size(349, 454);
            this.dataGridViewNguyenLieu.TabIndex = 33;
            this.dataGridViewNguyenLieu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNguyenLieu_CellClick);
            // 
            // lbma
            // 
            this.lbma.AutoSize = true;
            this.lbma.Location = new System.Drawing.Point(160, 314);
            this.lbma.Name = "lbma";
            this.lbma.Size = new System.Drawing.Size(52, 16);
            this.lbma.TabIndex = 35;
            this.lbma.Text = "Món Ăn";
            // 
            // lbkho
            // 
            this.lbkho.AutoSize = true;
            this.lbkho.Location = new System.Drawing.Point(958, 58);
            this.lbkho.Name = "lbkho";
            this.lbkho.Size = new System.Drawing.Size(108, 16);
            this.lbkho.TabIndex = 36;
            this.lbkho.Text = "Kho Nguyên Liệu";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1194, 543);
            this.Controls.Add(this.lbkho);
            this.Controls.Add(this.lbma);
            this.Controls.Add(this.dataGridViewNguyenLieu);
            this.Controls.Add(this.timnl);
            this.Controls.Add(this.txtFindNL);
            this.Controls.Add(this.btnThemNL);
            this.Controls.Add(this.lbdonvi);
            this.Controls.Add(this.lbsoluongnl);
            this.Controls.Add(this.lbtennl);
            this.Controls.Add(this.lbmanl);
            this.Controls.Add(this.txtDonVi);
            this.Controls.Add(this.txtSLNL);
            this.Controls.Add(this.txtTenNguyenLieu);
            this.Controls.Add(this.txtMaNguyenLieu);
            this.Controls.Add(this.btnXoaNL);
            this.Controls.Add(this.btnSuaNL);
            this.Controls.Add(this.lbCongThuc);
            this.Controls.Add(this.dataGrindCongThuc);
            this.Controls.Add(this.btnTimkiem);
            this.Controls.Add(this.txttimkiem);
            this.Controls.Add(this.btnthem);
            this.Controls.Add(this.lbGia);
            this.Controls.Add(this.lbLoai);
            this.Controls.Add(this.lbTen);
            this.Controls.Add(this.lbMaMonAn);
            this.Controls.Add(this.txtGia);
            this.Controls.Add(this.txtLoai);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.txtMaMonAn);
            this.Controls.Add(this.btnxoa);
            this.Controls.Add(this.btnsua);
            this.Controls.Add(this.dataGrindViewMonAn);
            this.Name = "Form1";
            this.Text = "Thông tin Món ăn";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindViewMonAn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindCongThuc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNguyenLieu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrindViewMonAn;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.TextBox txtMaMonAn;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtLoai;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label lbMaMonAn;
        private System.Windows.Forms.Label lbTen;
        private System.Windows.Forms.Label lbLoai;
        private System.Windows.Forms.Label lbGia;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.TextBox txttimkiem;
        private System.Windows.Forms.Label btnTimkiem;
        private System.Windows.Forms.DataGridView dataGrindCongThuc;
        private System.Windows.Forms.Label lbCongThuc;
        private System.Windows.Forms.Label timnl;
        private System.Windows.Forms.TextBox txtFindNL;
        private System.Windows.Forms.Button btnThemNL;
        private System.Windows.Forms.Label lbdonvi;
        private System.Windows.Forms.Label lbsoluongnl;
        private System.Windows.Forms.Label lbtennl;
        private System.Windows.Forms.Label lbmanl;
        private System.Windows.Forms.TextBox txtDonVi;
        private System.Windows.Forms.TextBox txtSLNL;
        private System.Windows.Forms.TextBox txtTenNguyenLieu;
        private System.Windows.Forms.TextBox txtMaNguyenLieu;
        private System.Windows.Forms.Button btnXoaNL;
        private System.Windows.Forms.Button btnSuaNL;
        private System.Windows.Forms.DataGridView dataGridViewNguyenLieu;
        private System.Windows.Forms.Label lbma;
        private System.Windows.Forms.Label lbkho;
    }
}

