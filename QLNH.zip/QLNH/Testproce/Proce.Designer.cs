﻿namespace Testproce
{
    partial class QLHD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbtruyvan = new System.Windows.Forms.Label();
            this.TbDanhSach = new System.Windows.Forms.GroupBox();
            this.lsvDanhSach = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbChiTiet = new System.Windows.Forms.GroupBox();
            this.lsvChiTiet = new System.Windows.Forms.ListView();
            this.MDH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MAMA = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SL = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GIA = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbDanhSach.SuspendLayout();
            this.TbChiTiet.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbtruyvan
            // 
            this.lbtruyvan.AutoSize = true;
            this.lbtruyvan.Location = new System.Drawing.Point(406, 32);
            this.lbtruyvan.Name = "lbtruyvan";
            this.lbtruyvan.Size = new System.Drawing.Size(112, 16);
            this.lbtruyvan.TabIndex = 0;
            this.lbtruyvan.Text = "Quản Lý Hoá Đơn";
            this.lbtruyvan.Click += new System.EventHandler(this.label1_Click);
            // 
            // TbDanhSach
            // 
            this.TbDanhSach.Controls.Add(this.lsvDanhSach);
            this.TbDanhSach.Location = new System.Drawing.Point(12, 92);
            this.TbDanhSach.Name = "TbDanhSach";
            this.TbDanhSach.Size = new System.Drawing.Size(495, 431);
            this.TbDanhSach.TabIndex = 1;
            this.TbDanhSach.TabStop = false;
            this.TbDanhSach.Text = "Danh Sách Hoá Đơn";
            // 
            // lsvDanhSach
            // 
            this.lsvDanhSach.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lsvDanhSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvDanhSach.FullRowSelect = true;
            this.lsvDanhSach.GridLines = true;
            this.lsvDanhSach.HideSelection = false;
            this.lsvDanhSach.Location = new System.Drawing.Point(3, 18);
            this.lsvDanhSach.Name = "lsvDanhSach";
            this.lsvDanhSach.Size = new System.Drawing.Size(489, 410);
            this.lsvDanhSach.TabIndex = 0;
            this.lsvDanhSach.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSach.View = System.Windows.Forms.View.Details;
            this.lsvDanhSach.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã ĐH";
            this.columnHeader1.Width = 86;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mã NV";
            this.columnHeader2.Width = 91;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Mã KH";
            this.columnHeader3.Width = 107;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Ngày ĐH";
            this.columnHeader4.Width = 93;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Tổng tiền";
            this.columnHeader5.Width = 108;
            // 
            // TbChiTiet
            // 
            this.TbChiTiet.Controls.Add(this.lsvChiTiet);
            this.TbChiTiet.Location = new System.Drawing.Point(561, 92);
            this.TbChiTiet.Name = "TbChiTiet";
            this.TbChiTiet.Size = new System.Drawing.Size(348, 434);
            this.TbChiTiet.TabIndex = 2;
            this.TbChiTiet.TabStop = false;
            this.TbChiTiet.Text = "Thông tin chi tiết Hoá Đơn";
            // 
            // lsvChiTiet
            // 
            this.lsvChiTiet.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MDH,
            this.MAMA,
            this.SL,
            this.GIA});
            this.lsvChiTiet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvChiTiet.FullRowSelect = true;
            this.lsvChiTiet.GridLines = true;
            this.lsvChiTiet.HideSelection = false;
            this.lsvChiTiet.Location = new System.Drawing.Point(3, 18);
            this.lsvChiTiet.Name = "lsvChiTiet";
            this.lsvChiTiet.Size = new System.Drawing.Size(342, 413);
            this.lsvChiTiet.TabIndex = 1;
            this.lsvChiTiet.UseCompatibleStateImageBehavior = false;
            this.lsvChiTiet.View = System.Windows.Forms.View.Details;
            // 
            // MDH
            // 
            this.MDH.Text = "Mã ĐH";
            this.MDH.Width = 68;
            // 
            // MAMA
            // 
            this.MAMA.Text = "Mã MA";
            this.MAMA.Width = 74;
            // 
            // SL
            // 
            this.SL.Text = "SL";
            this.SL.Width = 74;
            // 
            // GIA
            // 
            this.GIA.Text = "Giá";
            this.GIA.Width = 118;
            // 
            // QLHD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 538);
            this.Controls.Add(this.TbChiTiet);
            this.Controls.Add(this.TbDanhSach);
            this.Controls.Add(this.lbtruyvan);
            this.Name = "QLHD";
            this.Text = "QLHD";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TbDanhSach.ResumeLayout(false);
            this.TbChiTiet.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbtruyvan;
        private System.Windows.Forms.GroupBox TbDanhSach;
        private System.Windows.Forms.GroupBox TbChiTiet;
        private System.Windows.Forms.ListView lsvDanhSach;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView lsvChiTiet;
        private System.Windows.Forms.ColumnHeader MDH;
        private System.Windows.Forms.ColumnHeader MAMA;
        private System.Windows.Forms.ColumnHeader SL;
        private System.Windows.Forms.ColumnHeader GIA;
        private System.Windows.Forms.ColumnHeader columnHeader5;
    }
}

