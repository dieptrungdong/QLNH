﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Testproce
{
    public partial class QLHD : Form
    {
        string strCon = @"Data Source=DESKTOP-R8UMS8R\DONG2K2;Initial Catalog=QuanLyNhaHang;Integrated Security=True;";
        SqlConnection sqlCon = null;

        public QLHD()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;

            ListViewItem lvi = lsvDanhSach.SelectedItems[0];
            string MaDonHang = lvi.SubItems[0].Text.Trim();

            HienThiChiTiet(MaDonHang); ;
        }
        private void HienThiChiTiet(string MaDonHang)
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiChiTiet";

            SqlParameter parMaDonHang = new SqlParameter("@MaDonHang", SqlDbType.Char);
            parMaDonHang.Value = MaDonHang;
            sqlCmd.Parameters.Add(parMaDonHang);

            sqlCmd.Connection = sqlCon;
            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvChiTiet.Items.Clear();
            while (reader.Read())
            {
                string MaMonAn = reader.GetString(1);
                int Soluong = reader.GetInt32(2);
                decimal Gia = reader.GetDecimal(3);
                ListViewItem lvi = new ListViewItem(MaDonHang);
                lvi.SubItems.Add(MaMonAn);
                lvi.SubItems.Add(Soluong.ToString());
                lvi.SubItems.Add(Gia.ToString());
                lsvChiTiet.Items.Add(lvi);
            }
            reader.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }    
            if(sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }    
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiDSHD";
            sqlCmd.Connection = sqlCon;
            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while(reader.Read())
            {
                string MaDonHang = reader.GetString(0);
                string MaNhanVien = reader.GetString(1);
                string MaKhachHang = reader.GetString(2);
                DateTime NgayDatHang = reader.GetDateTime(3);
                decimal TongTien = reader.GetDecimal(4);
                ListViewItem lvi = new ListViewItem(MaDonHang);
                lvi.SubItems.Add(MaNhanVien);
                lvi.SubItems.Add(MaKhachHang);
                lvi.SubItems.Add(NgayDatHang.ToString("MM/dd/yyyy"));
                lvi.SubItems.Add(TongTien.ToString());
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            
        }
    }
}
