﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace QuanLyNhaHangWin
{
    class NhanVienBLL
    {
        NhanVienDAL dalNV;
        public NhanVienBLL()
        {
            dalNV = new NhanVienDAL();
        }
        public DataTable GetAllNhanVien()
        {
            return dalNV.GetAllNhanVien();
        }
        public bool InsertNhanVien(NhanVien nv)
        {
            return dalNV.InsertNhanVien(nv);
        }
        public bool UpdateNhanVien(NhanVien nv)
        {
            return dalNV.UpdateNhanVien(nv);
        }
        public bool DeleteNhanVien(NhanVien nv)
        {
            return dalNV.DeleteNhanVien(nv);
        }
        public DataTable TimNhanVien(string nv)
        {
            return dalNV.TimNhanVien(nv);
        }
    }
    
}
