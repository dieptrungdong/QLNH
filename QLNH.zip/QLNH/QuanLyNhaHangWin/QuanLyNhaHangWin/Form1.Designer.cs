﻿namespace QuanLyNhaHangWin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrindViewNhanVien = new System.Windows.Forms.DataGridView();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.txtMaNhanVien = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtSoDienThoai = new System.Windows.Forms.TextBox();
            this.txtMaChucVu = new System.Windows.Forms.TextBox();
            this.lbMaNhanVien = new System.Windows.Forms.Label();
            this.lbTen = new System.Windows.Forms.Label();
            this.lbSoDienThoai = new System.Windows.Forms.Label();
            this.lbMaChucVu = new System.Windows.Forms.Label();
            this.btnthem = new System.Windows.Forms.Button();
            this.txttimkiem = new System.Windows.Forms.TextBox();
            this.btnTimkiem = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindViewNhanVien)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrindViewNhanVien
            // 
            this.dataGrindViewNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrindViewNhanVien.Location = new System.Drawing.Point(12, 294);
            this.dataGrindViewNhanVien.Name = "dataGrindViewNhanVien";
            this.dataGrindViewNhanVien.RowHeadersWidth = 51;
            this.dataGrindViewNhanVien.RowTemplate.Height = 24;
            this.dataGrindViewNhanVien.Size = new System.Drawing.Size(553, 198);
            this.dataGrindViewNhanVien.TabIndex = 0;
            this.dataGrindViewNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrindViewNhanVien_CellClick);
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(119, 262);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(75, 23);
            this.btnsua.TabIndex = 2;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = true;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(200, 262);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(75, 23);
            this.btnxoa.TabIndex = 4;
            this.btnxoa.Text = "Xoá";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // txtMaNhanVien
            // 
            this.txtMaNhanVien.Location = new System.Drawing.Point(173, 12);
            this.txtMaNhanVien.Name = "txtMaNhanVien";
            this.txtMaNhanVien.Size = new System.Drawing.Size(187, 22);
            this.txtMaNhanVien.TabIndex = 5;
            this.txtMaNhanVien.TextChanged += new System.EventHandler(this.MaNhanVIen_TextChanged);
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(173, 65);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(187, 22);
            this.txtTen.TabIndex = 6;
            this.txtTen.TextChanged += new System.EventHandler(this.TenNhanVIen_TextChanged);
            // 
            // txtSoDienThoai
            // 
            this.txtSoDienThoai.Location = new System.Drawing.Point(173, 117);
            this.txtSoDienThoai.Name = "txtSoDienThoai";
            this.txtSoDienThoai.Size = new System.Drawing.Size(187, 22);
            this.txtSoDienThoai.TabIndex = 7;
            this.txtSoDienThoai.TextChanged += new System.EventHandler(this.txtSoDienThoai_TextChanged);
            // 
            // txtMaChucVu
            // 
            this.txtMaChucVu.Location = new System.Drawing.Point(173, 175);
            this.txtMaChucVu.Name = "txtMaChucVu";
            this.txtMaChucVu.Size = new System.Drawing.Size(187, 22);
            this.txtMaChucVu.TabIndex = 8;
            this.txtMaChucVu.TextChanged += new System.EventHandler(this.txtMaChucVu_TextChanged);
            // 
            // lbMaNhanVien
            // 
            this.lbMaNhanVien.AutoSize = true;
            this.lbMaNhanVien.Location = new System.Drawing.Point(35, 15);
            this.lbMaNhanVien.Name = "lbMaNhanVien";
            this.lbMaNhanVien.Size = new System.Drawing.Size(91, 16);
            this.lbMaNhanVien.TabIndex = 9;
            this.lbMaNhanVien.Text = "Mã Nhân Viên";
            this.lbMaNhanVien.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbTen
            // 
            this.lbTen.AutoSize = true;
            this.lbTen.Location = new System.Drawing.Point(35, 68);
            this.lbTen.Name = "lbTen";
            this.lbTen.Size = new System.Drawing.Size(96, 16);
            this.lbTen.TabIndex = 10;
            this.lbTen.Text = "Tên Nhân Viên";
            this.lbTen.Click += new System.EventHandler(this.TenNhanVien_Click);
            // 
            // lbSoDienThoai
            // 
            this.lbSoDienThoai.AutoSize = true;
            this.lbSoDienThoai.Location = new System.Drawing.Point(35, 120);
            this.lbSoDienThoai.Name = "lbSoDienThoai";
            this.lbSoDienThoai.Size = new System.Drawing.Size(86, 16);
            this.lbSoDienThoai.TabIndex = 11;
            this.lbSoDienThoai.Text = "Số Điện thoại";
            this.lbSoDienThoai.Click += new System.EventHandler(this.SoDienThoai_Click);
            // 
            // lbMaChucVu
            // 
            this.lbMaChucVu.AutoSize = true;
            this.lbMaChucVu.Location = new System.Drawing.Point(35, 178);
            this.lbMaChucVu.Name = "lbMaChucVu";
            this.lbMaChucVu.Size = new System.Drawing.Size(78, 16);
            this.lbMaChucVu.TabIndex = 12;
            this.lbMaChucVu.Text = "Mã Chức Vụ";
            this.lbMaChucVu.Click += new System.EventHandler(this.MaChucVu_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(38, 262);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(75, 23);
            this.btnthem.TabIndex = 14;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.them_Click);
            // 
            // txttimkiem
            // 
            this.txttimkiem.Location = new System.Drawing.Point(173, 220);
            this.txttimkiem.Name = "txttimkiem";
            this.txttimkiem.Size = new System.Drawing.Size(308, 22);
            this.txttimkiem.TabIndex = 16;
            this.txttimkiem.TextChanged += new System.EventHandler(this.txttimkiem_TextChanged);
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.AutoSize = true;
            this.btnTimkiem.Location = new System.Drawing.Point(35, 223);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(79, 16);
            this.btnTimkiem.TabIndex = 17;
            this.btnTimkiem.Text = "Nhập đề tìm";
            this.btnTimkiem.Click += new System.EventHandler(this.btnTimkiem_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(580, 504);
            this.Controls.Add(this.btnTimkiem);
            this.Controls.Add(this.txttimkiem);
            this.Controls.Add(this.btnthem);
            this.Controls.Add(this.lbMaChucVu);
            this.Controls.Add(this.lbSoDienThoai);
            this.Controls.Add(this.lbTen);
            this.Controls.Add(this.lbMaNhanVien);
            this.Controls.Add(this.txtMaChucVu);
            this.Controls.Add(this.txtSoDienThoai);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.txtMaNhanVien);
            this.Controls.Add(this.btnxoa);
            this.Controls.Add(this.btnsua);
            this.Controls.Add(this.dataGrindViewNhanVien);
            this.Name = "Form1";
            this.Text = "Thông tin nhân viên";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrindViewNhanVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrindViewNhanVien;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.TextBox txtMaNhanVien;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtSoDienThoai;
        private System.Windows.Forms.TextBox txtMaChucVu;
        private System.Windows.Forms.Label lbMaNhanVien;
        private System.Windows.Forms.Label lbTen;
        private System.Windows.Forms.Label lbSoDienThoai;
        private System.Windows.Forms.Label lbMaChucVu;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.TextBox txttimkiem;
        private System.Windows.Forms.Label btnTimkiem;
    }
}

