﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyNhaHangWin
{
    class NhanVien
    {
        public string MaNhanVien { get; set; }
        public string Ten {  get; set; }
        public string SoDienThoai { get; set; }
        public string MaChucVu { get; set; }
    }
}
