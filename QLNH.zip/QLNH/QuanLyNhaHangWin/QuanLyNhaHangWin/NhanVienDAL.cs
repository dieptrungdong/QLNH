﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyNhaHangWin
{
    class NhanVienDAL
    {
        DataConnection dc;
        SqlDataAdapter da;
        SqlCommand cmd;
        public NhanVienDAL()
        {
            dc = new DataConnection();
        }
        public DataTable GetAllNhanVien()
        {
            string sql = "SELECT * from NhanVien";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public bool InsertNhanVien(NhanVien nv)
        {
            string sql = "INSERT INTO NhanVien(MaNhanVien, Ten, SoDienThoai, MaChucVu) VALUES(@MaNhanVien, @Ten, @SoDienThoai, @MaChucVu)";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNhanVien", SqlDbType.Char).Value = nv.MaNhanVien;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar).Value = nv.Ten;
                cmd.Parameters.Add("@SoDienThoai", SqlDbType.VarChar).Value = nv.SoDienThoai;
                cmd.Parameters.Add("@MaChucVU", SqlDbType.Char).Value = nv.MaChucVu;
                cmd.ExecuteNonQuery();
                con.Close() ;
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool UpdateNhanVien(NhanVien nv)
        {
            string sql = "UPDATE NhanVien SET Ten=@Ten, SoDienThoai=@SoDienThoai, MaChucVu=@MaChucVu WHERE MaNhanVien=@MaNhanVien";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNhanVien", SqlDbType.Char).Value = nv.MaNhanVien;
                cmd.Parameters.Add("@Ten", SqlDbType.NVarChar).Value = nv.Ten;
                cmd.Parameters.Add("@SoDienThoai", SqlDbType.VarChar).Value = nv.SoDienThoai;
                cmd.Parameters.Add("@MaChucVU", SqlDbType.Char).Value = nv.MaChucVu;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool DeleteNhanVien(NhanVien nv)
        {
            string sql = "DELETE NhanVien WHERE MaNhanVien=@MaNhanVien";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaNhanVien", SqlDbType.Char).Value = nv.MaNhanVien;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public DataTable TimNhanVien(string nv)
        {
            string sql = "SELECT * FROM NhanVien Where Ten like N'%" + nv + "'";
            SqlConnection con = dc.GetConnect();
            da = new SqlDataAdapter(sql, con);
            con.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

    } 
}
