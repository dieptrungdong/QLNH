﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace QuanLyNhaHangWin
{
    class DataConnection    
    {
        string conStr;
        public DataConnection()
        {
            conStr = @"Data Source=DESKTOP-R8UMS8R\DONG2K2;Initial Catalog=QuanLyNhaHang;Integrated Security=True;";
        }
        public SqlConnection GetConnect()
        { return new SqlConnection(conStr); }
    }
}
