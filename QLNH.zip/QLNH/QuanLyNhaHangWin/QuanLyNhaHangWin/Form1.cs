﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyNhaHangWin
{
    public partial class Form1 : Form
    {
        NhanVienBLL bllNV;
        public Form1()
        {
            InitializeComponent();
            bllNV = new NhanVienBLL();
        }
        public void ShowAllNhanVien()
        {
            DataTable dt = bllNV.GetAllNhanVien();
            dataGrindViewNhanVien.DataSource = dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowAllNhanVien();
        }
        public bool CheckData()
        {
            if (string.IsNullOrEmpty(txtMaNhanVien.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã nhân viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaNhanVien.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtTen.Text))
            {
                MessageBox.Show("Bạn chưa nhập Tên nhân viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTen.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtSoDienThoai.Text))
            {
                MessageBox.Show("Bạn chưa nhập Số điện thoại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSoDienThoai.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtMaChucVu.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã chức vụ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaChucVu.Focus();
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void MaNhanVIen_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TenNhanVIen_TextChanged(object sender, EventArgs e)
        {

        }

        private void them_Click(object sender, EventArgs e)
        {
            if (CheckData())
            {
                NhanVien nv = new NhanVien();
                nv.MaNhanVien = txtMaNhanVien.Text;
                nv.Ten = txtTen.Text;
                nv.SoDienThoai = txtSoDienThoai.Text;
                nv.MaChucVu = txtMaChucVu.Text;

                if (bllNV.InsertNhanVien(nv))
                    ShowAllNhanVien();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void MaChucVu_Click(object sender, EventArgs e)
        {

        }

        private void SoDienThoai_Click(object sender, EventArgs e)
        {

        }

        private void TenNhanVien_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            if (CheckData())
            {
                NhanVien nv = new NhanVien();
                nv.MaNhanVien = txtMaNhanVien.Text;
                nv.Ten = txtTen.Text;
                nv.SoDienThoai = txtSoDienThoai.Text;
                nv.MaChucVu = txtMaChucVu.Text;

                if (bllNV.UpdateNhanVien(nv))
                    ShowAllNhanVien();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn xoá hay không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                NhanVien nv = new NhanVien();
                nv.MaNhanVien = txtMaNhanVien.Text;
                if (bllNV.DeleteNhanVien(nv))
                    ShowAllNhanVien();
                else
                    MessageBox.Show("Đã có lỗi xảy ra, thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void dataGrindViewNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if(index >=0 )
            {
                txtMaNhanVien.Text= dataGrindViewNhanVien.Rows[index].Cells["MaNhanVien"].Value.ToString();
                txtTen.Text = dataGrindViewNhanVien.Rows[index].Cells["Ten"].Value.ToString();
                txtSoDienThoai.Text = dataGrindViewNhanVien.Rows[index].Cells["SoDienThoai"].Value.ToString();
                txtMaChucVu.Text = dataGrindViewNhanVien.Rows[index].Cells["MaChucVu"].Value.ToString();
            }
        }

        private void txttimkiem_TextChanged(object sender, EventArgs e)
        {
            string value = txttimkiem.Text;
            if (!string.IsNullOrEmpty(value))
            {
                DataTable dt = bllNV.TimNhanVien(value);
                dataGrindViewNhanVien.DataSource = dt;
            }
            else
                ShowAllNhanVien();
        }

        private void txtSoDienThoai_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMaChucVu_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {

        }
    }
}
